/**
 * Suma dos números.
 * @param {number} a - Primer número
 * @param {number} b - Segundo número
 * @returns {number} La suma de a y b
 */
function suma(a, b) {
    return a + b;
}

/**
 * Multiplica dos números.
 * @param {number} a - Primer número
 * @param {number} b - Segundo número
 * @returns {number} El producto de a y b
 */
function multiplica(a, b) {
    return a * b;
}
