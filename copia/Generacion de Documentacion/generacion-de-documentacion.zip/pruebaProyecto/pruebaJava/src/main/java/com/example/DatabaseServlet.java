package com.example;

    import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

@WebServlet("/data")
public class DatabaseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();
        JSONArray jsonArray = new JSONArray();

        try {
            // Conexión a la base de datos
            String url = "jdbc:mysql://localhost:3306/tu_base_de_datos";
            String user = "tu_usuario";
            String password = "tu_contraseña";

            Connection conn = DriverManager.getConnection(url, user, password);
            Statement stmt = conn.createStatement();
            String query = "SELECT id, nombre FROM tu_tabla";
            ResultSet rs = stmt.executeQuery(query);

            // Convertir ResultSet en JSON
            while (rs.next()) {
                JSONObject jsonObj = new JSONObject();
                jsonObj.put("id", rs.getInt("id"));
                jsonObj.put("nombre", rs.getString("nombre"));
                jsonArray.add(jsonObj);
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        out.print(jsonArray.toJSONString());
        out.flush();
    }
}

